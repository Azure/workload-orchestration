# 1. RGCleanScript.ps1

This script is used to clean up resources in a specified Azure Resource Group. It provides options to skip the deletion of certain resources.

## 1.1 Prerequisites

- If running the script locally then you need to have Azure CLI installed and authenticated. Necessary permissions to delete resources in the specified resource group[For most of cases, by default your alias will have permission]



## 1.2 Parameters

- `resourceGroupName` [Required] (string): The name of the resource group to clean.
- `contextSubscriptionId` [Optional] (string): Subscription ID where context is present (For Microsoft.Edge). Default is `973d15c6-6c57-447e-b9c6-6d79b5b784ab`.
- `contextResourceGroupName` [Optional] (string): RG of the Context (For Microsoft.Edge). Default is `Mehoopany`.
- `contextName` [Optional] (string): Name of the Context (For Microsoft.Edge). Default is `Mehoopany-Context`.
- `skipSiteDeletion` [Optional] (bool): Skip deletion of site resources. Default is `false`.
- `skipTargetDeletion` [Optional] (bool): Skip deletion of target resources. Default is `false`.
- `skipConfigurationDeletion` [Optional] (bool): Skip deletion of CM created configuration resources. Default is `false`.
- `skipSchemaDeletion` [Optional] (bool): Skip deletion of schema/dynamic schema resources. Default is `false`.
- `skipConfigTemplateDeletion` [Optional] (bool): Skip deletion of user created config template resources. Default is `false`.
- `skipSolutionDeletion` [Optional] (bool): Skip deletion of solution template resources. Default is `false`.
- `skipAksDeletion` [Optional] (bool): Skip deletion of AKS cluster resources. Default is `false`.

## 1.3 Usage 

```powershell
.\RGCleanScript.ps1 -resourceGroupName <YourResourceGroupName> [-skipSiteAndAddressDeletion $true] [-skipTargetDeletion $true] 
```
